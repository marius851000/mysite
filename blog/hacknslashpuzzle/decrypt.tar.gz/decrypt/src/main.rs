use std::{fs::{File, read_dir}, io::{Read, Write}, sync::Arc, path::{Path, PathBuf}, str::from_utf8, os::unix::prelude::MetadataExt};

use aes::cipher::{KeyIvInit, BlockDecryptMut, block_padding::ZeroPadding};
use sha2::{Sha256, Digest};
use work_queue::Queue;

pub fn add_result(r: Vec<u8>, encrypted: &[u8]) {
    println!("Found result {:?}", r);
    match from_utf8(&r) {
        Ok(r) => println!("as text : \"{}\"", r),
        Err(_) => println!("not a valid string")
    }
    let mut decrypted = vec![0; encrypted.len()];
    decrypt(&r, encrypted, &mut decrypted);

    let mut out_file = File::create(hex::encode(&r)).unwrap();
    out_file.write_all(&decrypted).unwrap();
}

fn decrypt(key: &[u8], encrypted_content: &[u8], out_buffer: &mut [u8]) {
    let key_hash: [u8; 32] = Sha256::digest(key).into();
    let iv = [0; 0x10];

    //TODO: enable asm for sha2, multithreading
    let aes_256_cbc_dec = cbc::Decryptor::<aes::Aes256>::new(&key_hash.into(), &iv.into());
    let mut out_buf = Vec::with_capacity(encrypted_content.len());
    out_buf.resize(encrypted_content.len(), 0);
    aes_256_cbc_dec.decrypt_padded_b2b_mut::<ZeroPadding>(&encrypted_content, out_buffer).unwrap();
}

fn decrypt_first_section(key: &[u8], encrypted_content: &[u8], out_buffer: &mut [u8; 256]) {
    decrypt(key, &encrypted_content[0..256], out_buffer);
}

fn seem_valid_lua(content: &[u8; 256]) -> bool {
    for possibility in [&content[0..4], &content[4..8]].into_iter() {
        if possibility == [0x1b, b'L', b'u', b'a'] {
            return true;
        }
        if possibility == [b'l', b'o', b'c', b'a'] {
            return true;
        }
        if possibility[0..3] == [b'-', b'-', b' '] {
            return true;
        }
        if possibility == [b'-', b'-', b'-', b'-'] {
            return true;
        }
    }
    return false;
}

fn try_crack_over_content(input_content: &[u8], encrypted_content: &[u8], size: usize) {
    if input_content.len() < size {
        return;
    }
    let mut decrypt_out_buffer = [0; 256];
    for start in 0..input_content.len() - size {
        let key_slice = &input_content[start..start+size];
        decrypt_first_section(key_slice, encrypted_content, &mut decrypt_out_buffer);
        if seem_valid_lua(&decrypt_out_buffer) {
            add_result(key_slice.to_vec(), encrypted_content);
        }
    }
}

fn path_to_vec(path: &Path) -> Vec<u8> {
    let mut file = File::open(path).unwrap();
    let mut result = Vec::new();
    file.read_to_end(&mut result).unwrap();
    return result;
}

//const KEY: &[u8] = "With this incantation the princess I do bind and protect.".as_bytes();

fn find_and_filter_files(path: &Path, result: &mut Vec<PathBuf>, sum_size: &mut usize) {
    for entry in read_dir(path).unwrap().into_iter().map(|x| x.unwrap()) {
        if entry.file_type().unwrap().is_dir() {
            find_and_filter_files(&entry.path(), result, sum_size);
        } else {
            let file_name = entry.file_name().into_string().unwrap();
            if file_name.ends_with(".dds.gz") || file_name.ends_with(".fsv") || file_name.ends_with(".fsb") || file_name.ends_with(".png") {
                continue
            }
            *sum_size += entry.metadata().unwrap().size() as usize;
            result.push(entry.path());
        }
    }
}

fn hack_multi_thread(encrypted_content: Arc<Vec<u8>>, search_folder: &Path) {
    let mut result = Vec::new();
    let mut sum_size = 0;
    find_and_filter_files(search_folder, &mut result, &mut sum_size);
    println!("working on {} bytes", sum_size);
    let queue: Queue<(PathBuf, usize)> = Queue::new(16, 128);

    for file in result {
        for size in 1..61 {
            //done: 4-8 up to 161
            //done: 0-4 up to 0
            queue.push((file.clone(), size));
        }
    }

    let mut handles = Vec::new();
    for mut local_queue in queue.local_queues() {
        let local_encrypted_content = encrypted_content.clone();
        let h = std::thread::spawn(move || {
            while let Some((file_path, size)) = local_queue.pop() {
                let file_content = path_to_vec(&file_path); //TODO: maybe cache in memory?
                try_crack_over_content(&file_content, &local_encrypted_content, size);
            }
        });
        handles.push(h);
    }
    
    for handle in handles {
        handle.join().unwrap();
    }
}

fn main() {
    //let princess_room_encrypted = path_to_vec(&PathBuf::from("../test.bin"));
    //hack_multi_thread(Arc::new(princess_room_encrypted), &PathBuf::from("/home/marius/.local/share/Steam/steamapps/common/HacknSlash/Data/Content/Game/DourTower/"));

    let secret_encrypted = path_to_vec(&PathBuf::from("/home/marius/.local/share/Steam/steamapps/common/HacknSlash/Data/Content/Secret/Rooms/SecretRoom.lua"));
    hack_multi_thread(Arc::new(secret_encrypted), &PathBuf::from("/home/marius/.local/share/Steam/steamapps/common/HacknSlash/"));


    /*let crack_result = CrackResult::new();
    let input_contain_key = path_to_vec(&PathBuf::from("/home/marius/.local/share/Steam/steamapps/common/HacknSlash/Hack"));
    
    println!("{}", KEY.len());
    try_crack_over_content(&input_contain_key, &input_encrypted, KEY.len(), &crack_result);*/



    /*let mut out = File::create("../out.bin").unwrap();

    let mut decrypt_out = [0; 256];
    decrypt_first_section(key, &input_encrypted, &mut decrypt_out);

    out.write_all(&decrypt_out).unwrap();*/
}
